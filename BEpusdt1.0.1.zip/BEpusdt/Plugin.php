<?php

namespace Plugin\BEpusdt;

use App\Services\Plugin\AbstractPlugin;
use App\Contracts\PaymentInterface;

class Plugin extends AbstractPlugin implements PaymentInterface
{
    public function boot(): void
    {
        $this->filter('available_payment_methods', function ($methods) {
            if ($this->getConfig('enabled', true)) {
                $methods['BEpusdt'] = [
                    'name' => $this->getConfig('display_name', 'USDT 支付'),
                    'icon' => $this->getConfig('icon', '💰'),
                    'plugin_code' => $this->getPluginCode(),
                    'type' => 'plugin'
                ];
            }
            return $methods;
        });
    }

    public function form(): array
    {
        return [
            'url' => [
                'label' => 'BEpusdt API 地址',
                'type' => 'string',
                'required' => true,
                'description' => '例如：https://xxxxx.com'
            ],
            'api_token' => [
                'label' => 'API Token',
                'type' => 'string',
                'required' => true,
            ],
            'trade_type' => [
                'label' => '链类型',
                'type' => 'string',
                'required' => false,
                'description' => '默认 usdt.trc20，可选 usdt.erc20 / trx 等'
            ]
        ];
    }


    public function pay($order): array
    {
        $tradeType = $this->getConfig('trade_type', 'usdt.trc20');

        // BEpusdt API 参数
        $params = [
            "address" => "",
            "trade_type" => $tradeType,
            "order_id" => $order['trade_no'],
            "amount" => $order['total_amount'] / 100,
            "notify_url" => $order['notify_url'],
            "redirect_url" => $order['return_url'],
            "timeout" => 600
        ];


        $params["signature"] = $this->makeSign($params);

        $apiUrl = rtrim($this->getConfig('url'), '/') . '/api/v1/order/create-transaction';

        $response = $this->curlPostJson($apiUrl, $params);
        if (!$response || empty($response['data']['payment_url'])) {
            throw new \Exception("BEpusdt 创建订单失败：" . json_encode($response, 256));
        }

        return [
            'type' => 1,
            'data' => $response['data']['payment_url']
        ];
    }


    public function notify($params): array|bool
    {

        $sign = $params["signature"] ?? "";
        unset($params["signature"]);

        if ($sign !== $this->makeSign($params)) {
            return false;
        }

        if (($params['status'] ?? 0) != 2) {
            return false;
        }

        return [
            "trade_no" => $params["order_id"],
            "callback_no" => $params["trade_id"]
        ];
    }


    private function makeSign(array $data): string
    {

        $data = array_filter($data, function ($v) {
            return $v !== "" && $v !== null;
        });

        ksort($data);

        $str = "";
        foreach ($data as $k => $v) {
            $str .= "{$k}={$v}&";
        }
        $str = rtrim($str, "&");

        $str .= $this->getConfig("api_token");

        return strtolower(md5($str));
    }


    private function curlPostJson($url, $data)
    {
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode($data),
        ]);

        $response = curl_exec($curl);
        curl_close($curl);

        return json_decode($response, true);
    }
}

